package com.pluralsight.hibernatefundamentals.airport;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

public class QueriesTest {

    private static EntityManagerFactory emf;

    @BeforeAll
    static void beforeAll() {
        emf = Persistence.createEntityManagerFactory("hibernatefundamentals.m07.ex01");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        Passenger john = new Passenger("John Smith");
        Passenger mike = new Passenger("Michael Johnson");

        em.persist(john);
        em.persist(mike);

        em.getTransaction().commit();
        em.close();
    }

    @Test
    void testSimpleQueries() {
    }

    @AfterAll
    static void afterAll() {
        emf.close();
    }
}
