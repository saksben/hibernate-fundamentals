package com.pluralsight.hibernatefundamentals.airport;

import jakarta.persistence.*;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class QueriesTest {

    private static EntityManagerFactory emf;

    @BeforeAll
    static void beforeAll() {
        emf = Persistence.createEntityManagerFactory("hibernatefundamentals.m07.ex01");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        Passenger john = new Passenger("John Smith");
        Passenger mike = new Passenger("Michael Johnson");

        em.persist(john);
        em.persist(mike);

        em.getTransaction().commit();
        em.close();
    }

    @Test
    void testSimpleQueries() {
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT p FROM Passenger p");
        TypedQuery<Passenger> typedQuery = em.createQuery("SELECT p FROM Passenger p", Passenger.class);

        assertAll(() -> assertEquals(2, query.getResultList().size()),
                () -> assertEquals(2, typedQuery.getResultList().size()));
        em.close();
    }

    @AfterAll
    static void afterAll() {
        emf.close();
    }
}
