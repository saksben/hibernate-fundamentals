package com.pluralsight.hibernatefundamentals.airport;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "PASSENGERS")
@NoArgsConstructor
@NamedQueries({
        @NamedQuery(name = "Passenger.findAll", query = "select p from Passenger p ORDER BY p.name"),
        @NamedQuery(name = "Passenger.findByName", query = "select p from Passenger p where p.name = :name")
})
public class Passenger {
    @Id
    @GeneratedValue
    @Getter
    private int id;

    @Getter
    @Setter
    private String name;

    public Passenger(String name) {
        this.name = name;
    }

}
