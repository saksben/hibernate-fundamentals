package com.pluralsight.hibernatefundamentals.transactions;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Version;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@NoArgsConstructor
public class Ticket {
    @Id
    @GeneratedValue
    @Getter
    private int id;

    @Version
    @Getter
    private long version;

    @Getter
    @Setter
    private String number;

    @Getter
    @Setter
    private int price;

    public Ticket (String number, int price) {
        this.number = number;
        this.price = price;
    }

}
