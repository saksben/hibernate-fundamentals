package com.pluralsight.hibernatefundamentals.transactions;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

public class TransactionsTest {

    static EntityManagerFactory emf;

    @BeforeAll
    static void beforeAll() {
        emf = Persistence.createEntityManagerFactory("hibernatefundamentals.m06.ex01");
    }

    @Test
    void persistItem() {
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        Ticket someTicket = new Ticket("AA1234", 100);
        em.persist(someTicket);
        em.getTransaction().commit();
        em.close();
    }

    @Test
    void runTransaction1() {
        EntityManager em = emf.createEntityManager();

        em.getTransaction().begin();
        Ticket ticket = em.find(Ticket.class, 1);

        ticket.setPrice(95);
        em.getTransaction().commit();

    }

    @Test
    void runTransaction2() {
        EntityManager em = emf.createEntityManager();

        em.getTransaction().begin();
        Ticket ticket = em.find(Ticket.class, 1);

        ticket.setPrice(93);
        em.getTransaction().commit();

    }

    @AfterAll
    static void afterAll() {
        emf.close();
    }

}
