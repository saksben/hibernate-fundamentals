package com.pluralsight.hibernatefundamentals.airport;

import jakarta.persistence.*;
import jakarta.persistence.criteria.*;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class CriteriaBuilderTest {

    private static EntityManagerFactory emf;

    @BeforeAll
    static void beforeAll() {
        emf = Persistence.createEntityManagerFactory("hibernatefundamentals.m08.ex02");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        Flight flight = new Flight("AA1234");
        em.persist(flight);

        Passenger john = new Passenger("John Smith");
        Passenger mike = new Passenger("Michael Johnson");

        john.setFlight(flight);
        mike.setFlight(flight);

        em.persist(john);
        em.persist(mike);

        em.getTransaction().commit();
        em.close();
    }

    @Test
    void testSimpleCriteriaBuilder() {
        EntityManager em = emf.createEntityManager();

        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<Passenger> query = cb.createQuery(Passenger.class);
        Root<Passenger> root = query.from(Passenger.class);

        assertAll(() -> assertEquals(2, em.createQuery(query).getResultList().size()));
        em.close();
    }

    @ParameterizedTest
    @ValueSource(strings = {"John Smith", "Michael Johnson"})
    void testPassengersByNameUsingCriteriaBuilder(String name) {
        EntityManager em = emf.createEntityManager();

        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<Passenger> query = cb.createQuery(Passenger.class);
        Root<Passenger> fromClause = query.from(Passenger.class);

        query.select(fromClause).where(cb.equal(fromClause.get("name"), name));

        assertEquals(1, em.createQuery(query).getResultList().size());
        em.close();
    }

    @Test
    void testDistinctSelect() {
        EntityManager em = emf.createEntityManager();

        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<Flight> criteriaQuery = cb.createQuery(Flight.class);
        Root<Passenger> fromClause = criteriaQuery.from(Passenger.class);

        Selection<Flight> selection = fromClause.get("flight");

        criteriaQuery.select(selection).distinct(true);

        TypedQuery<Flight> query = em.createQuery(criteriaQuery);
        List<Flight> flights = query.getResultList();

        assertEquals(1, flights.size());

        em.close();
    }

    @Test
    void testMultiSelect() {
        EntityManager em = emf.createEntityManager();

        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<Object[]> criteriaQuery = cb.createQuery(Object[].class);
        Root<Passenger> fromClause = criteriaQuery.from(Passenger.class);

        Selection<Object[]> selectionFlightNumber = fromClause.get("flight").get("number");
        Selection<Object[]> selectionPassengerName = fromClause.get("name");

        criteriaQuery.select(cb.array(selectionFlightNumber, selectionPassengerName)).distinct(true);

        TypedQuery<Object[]> query = em.createQuery(criteriaQuery);
        List<Object[]> results = query.getResultList();

        assertEquals(2, results.size());

        em.close();
    }

    @Test
    void testJoin() {
        EntityManager em = emf.createEntityManager();

        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<Object[]> criteriaQuery = cb.createQuery(Object[].class);
        Root<Passenger> fromClause = criteriaQuery.from(Passenger.class);

        Join<Passenger, Flight> joinClause = fromClause.join("flight", JoinType.LEFT);

        Selection<?> flightNumber = joinClause.get("number");
        Selection<?> passengerName = fromClause.get("name");

        criteriaQuery.select(cb.array(flightNumber, passengerName));

        TypedQuery<Object[]> query = em.createQuery(criteriaQuery);
        List<Object[]> results = query.getResultList();

        for (Object[] res: results) {
            System.out.println(String.format("%1$s - %2$s", res[0], res[1]));
        }

        assertEquals(2, results.size());

        em.close();
    }

    @AfterAll
    static void afterAll() {
        emf.close();
    }
}
