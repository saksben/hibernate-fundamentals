package com.pluralsight.hibernatefundamentals.airport;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@NoArgsConstructor
@ToString
public class Flight {
    @Id
    @GeneratedValue
    @Getter
    private int id;

    @Getter
    @Setter
    private String number;

    public Flight(String number) {
        this.number = number;
    }

}
