package com.pluralsight.hibernatefundamentals.airport;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;

public class CriteriaBuilderTest {

    private static EntityManagerFactory emf;

    @BeforeAll
    static void beforeAll() {
        emf = Persistence.createEntityManagerFactory("hibernatefundamentals.m08.ex01");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        Flight flight = new Flight("AA1234");
        em.persist(flight);

        Passenger john = new Passenger("John Smith");
        Passenger mike = new Passenger("Michael Johnson");

        john.setFlight(flight);
        mike.setFlight(flight);

        em.persist(john);
        em.persist(mike);

        em.getTransaction().commit();
        em.close();
    }

    @AfterAll
    static void afterAll() {
        emf.close();
    }
}
